library(testthat)
test_check("diffr")
