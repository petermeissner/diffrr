#' This is the PLace to put OnLoad and OnAttach functions.
#' ... these are turned off

#  .onLoad   <- function(libname, pkgname){
#    packageStartupMessage("Uh, Package Loaded!")
#  }
#  .onAttach   <- function(libname, pkgname){
#    packageStartupMessage("Package Kind of Attached - I think.")
#  }

