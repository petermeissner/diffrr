#' sample text
#' @format a text
#' @source \url{http://en.wikipedia.org\n/w/index.php?title=Diff\n&oldid=622929855}
"example_A1"

#' sample text
#' @format a text
#' @source \url{http://en.wikipedia.org\n/w/index.php?title=Diff\n&oldid=622929855}
"example_A2"

#' sample text split into lines
#' @format a text
#' @source \url{http://en.wikipedia.org\n/w/index.php?title=Diff\n&oldid=622929855}
"example_A2_split"

#' sample text
#' @format a text split into lines
#' @source \url{http://en.wikipedia.org\n/w/index.php?title=Diff\n&oldid=622929855}
"example_A1_split"
